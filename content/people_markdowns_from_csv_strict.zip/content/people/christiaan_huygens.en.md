# Christiaan Huygens

## BIO
Christiaan Huygens (1629–1695) transformed time measurement in the Dutch Republic and Paris.

## WHAT
- Invented the pendulum clock (1656) and advanced balance‑spring watches.
- Published *Horologium* and *Horologium Oscillatorium*.

## WHY
Introduced a stable regulator that vastly increased accuracy.

## STORY+
Collaborated and clashed with Isaac Thuret over inventions.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Christiaan_Huygens)
