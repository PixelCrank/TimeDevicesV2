# Adrien Philippe

## BIO
Adrien Philippe (1815–1894) co‑founded Patek Philippe after perfecting crown (keyless) winding and setting.

## WHAT
- Patented a reliable keyless system (1845); advanced elegant cases and dials.

## WHY
His crown‑winding system became universal, transforming usability.

## STORY+
After prizes for his invention, he partnered with Antoni Patek to found a benchmark Geneva maison.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Adrien_Philippe)
