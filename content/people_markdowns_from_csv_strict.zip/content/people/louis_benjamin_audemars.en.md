# Louis-Benjamin Audemars

## BIO
Louis‑Benjamin Audemars (1782–1833) founded a Vallée de Joux workshop later renowned for complications.

## WHAT
- Specialised in very thin movements, repeaters and perpetual calendars, supplying top maisons.

## WHY
Helped establish the valley as a centre of fine, ultra‑thin, complicated movements.

## STORY+
The family’s networked workshop model powered Swiss complications.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Louis_Audemars)
