# Édouard Koehn

## BIO
Édouard Koehn (1839–1908) trained in Geneva, became director‑shareholder at Patek Philippe, then founded his own house after acquiring H.‑R. Ekegren.

## WHAT
- Patented a retrograde display (1892) coupled to a chronograph; produced elegant ultra‑thin complications.

## WHY
A discreet innovator marrying refined mechanics with Geneva style.

## STORY+
The retrograde complication faded then resurfaced; the Ed. Koehn name was revived in the 21st century.

## Sources

- [Le Point – Édouard Koehn](https://www.lepoint.fr/montres/edouard-koehn-03-12-2012-2018091_2648.php)
