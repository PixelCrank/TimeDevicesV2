# H.-L. Jaquet-Droz

## BIO
Henri‑Louis Jaquet‑Droz (1752–1791) was famed for lifelike automata and musical mechanisms.

## WHAT
- Created *The Writer*, *The Draughtsman*, *The Musician*; exported singing‑bird watches to China.

## WHY
United art, mechanics and illusion; pushed miniaturisation and complexity.

## STORY+
Court demonstrations opened export markets for Swiss luxury craft.

## Sources

- [Jaquet‑Droz – History](https://www.jaquet-droz.com)
