# Ferdinand Berthoud

## BIO
Ferdinand Berthoud (1727–1807) from Couvet moved to Paris and became a leading chronometer maker and author.

## WHAT
- Designed marine timekeepers for French expeditions; promoted chronometry as applied science.

## WHY
Championed the French effort in marine chronometers with rigorous testing.

## STORY+
His rivalry with Harrison is legendary; his name survives in a revived maison.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Ferdinand_Berthoud)
