# Jules Jürgensen

## BIO
Jules Jürgensen (1808–1877), Danish‑born, trained in England and worked in Switzerland.

## WHAT
- Produced elegant high‑grade pocket watches; experimented with winding systems and escapements.

## WHY
Represents the internationalisation of 19th‑century watchmaking.

## STORY+
The Jürgensen name long signified understated precision.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Jules_J%C3%BCrgensen)
