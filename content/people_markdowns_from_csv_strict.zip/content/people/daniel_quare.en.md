# Daniel Quare

## BIO
Daniel Quare (c.1647–1724) was a prominent London maker and later Master of the Clockmakers’ Company.

## WHAT
- Advanced repeating mechanisms and portable barometers.
- Popularised clear coaxial hour/minute hands.

## WHY
Made complications reliable for daily use.

## STORY+
Had a long priority dispute with Edward Barlow over the repeater.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Daniel_Quare)
