# Justin Vulliamy

## BIO
Justin Vulliamy (1712–1797) was a Swiss‑born horologist who settled in London.

## WHAT
- Co‑founded Gray & Vulliamy; spread/refined the cylinder escapement.
- Produced refined regulators and clocks for elites.

## WHY
Bridged Swiss craft and English innovation.

## STORY+
Helped found London’s Swiss Church in 1762 and donated a clock.

## Sources

- [Wikipedia](https://en.wikipedia.org/wiki/Vulliamy_(clockmakers))
