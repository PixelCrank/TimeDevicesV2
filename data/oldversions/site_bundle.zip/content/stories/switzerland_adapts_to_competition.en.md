# Switzerland Adapts to Competition

## Context
TBD

## What
TBD

## Why
TBD

## Story+
TBD
