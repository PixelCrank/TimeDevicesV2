# From Seasonal Time to Fixed Time

## Context
TBD

## What
TBD

## Why
TBD

## Story+
TBD
